# GTPS-HTTP-Server
Simple http server coded by NodeJS

## About GTPS-HTTP-Server
This http only receive ``POST`` request, in route ``growtopia/server_data.php``.This http will always show ``logs`` when someone log ``growtopia/server_data.php`` (Growtopia Server).
## Change Log
1. Added players data like ip, http version, and etc (when log growtopia/server_data.php with ``POST`` Method
2. Added logs in HTTP

# Instalation
```npm install log4js```

# How To Use (windows)
```node index.js```

# How to use (linux)
```sudo node index.js```

![image](https://camo.githubusercontent.com/e0e4984e0d2d74f6332277a2309cbb4e3d619e50/68747470733a2f2f63646e2e646973636f72646170702e636f6d2f6174746163686d656e74732f3734323638393633363330343032373636382f3736343431373834363836303035343533382f756e6b6e6f776e2e706e67)

![image](https://camo.githubusercontent.com/2db46f395cf686b54bb9369b26704ffd88d9dd3a/68747470733a2f2f63646e2e646973636f72646170702e636f6d2f6174746163686d656e74732f3734323638393633363330343032373636382f3737333533343436323233383532333433322f756e6b6e6f776e2e706e67)


